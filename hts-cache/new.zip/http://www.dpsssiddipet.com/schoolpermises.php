
<html lang="en" ng-app="schoolApp">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
  
    <title>Delhi Public Secondary School | Top CBSE School with Global Standards & Offering Franchise Success</title>
    <meta content="" name="description">
    <meta content="" name="keywords">
    <!-- Favicons -->
    <link href="/images/school-logo/siddipet-lg.png" rel="icon">
    <link href="/images/school-logo/siddipet-lg.png" rel="dpsslogo">
    <link href="/images/school-logo/siddipet-lg.png" rel="apple-touch-icon">
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">
    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body ng-controller="mainCtrl">
    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top">
        
        <div class="top-head">
            <div class="row">
                <!-- <div class="col-sm-12 col-md-4 col-lg-4 ">
                  <div style="color:white;" id="datetime2"></div>
               </div> -->
               <div class="col-sm-12 col-md-4 col-lg-4 ">
                    <div class="helpline">
                        <span style="margin-left: 10px;">
                            Admissions Helpline:
                            <i class="bi bi-telephone-fill"></i> +91 7660999981 |
                            <i class="bi bi-envelope-fill"></i> dpsssiddipet@gmail.com
                        </span>
                    </div>
               </div>
               <div class="col-sm-12 col-md-8 col-lg-8 ">
                    <div class="top-navbar-items">
                        <div class="header-top_nav">
                            <!-- <div class="hdr-li"><a href="#" target="_blank"><i class="fa fa-sign-in"></i>&nbsp; ERP Login</a> </div>  -->
                            <!-- <div class="hdr-li"><a href="#"> | </a> </div>  -->
                            <div class="hdr-li"><a href="javascript:void(0)"><i class="fa fa-file-text"></i>&nbsp; Mandatory Disclosure</a> </div> 
                            <div class="hdr-li"><a href="#"> | </a> </div> 
                            <div class="hdr-li"><a href="onlineRegis.php"><i class="far fa-edit"></i>&nbsp; Admission Enquiry Form</a> </div>
                            <div class="hdr-li"><a href="#"> | </a> </div>
                            <div class="hdr-li"><a href="javascript:void(0)"><i class="fas fa-paper-plane"></i>&nbsp; Notice </a></div>
                            <div class="hdr-li"><a href="#"> | </a> </div>
                            <div class="hdr-li"><a href="javascript:void(0)"><img src="/images/school-logo/360-icon.webp" style="margin-top: -4px; max-width: 26px; margin-right: 3px;">View</a>
                            </div>
                        </div>
                        
                        <div class="social-icons">
                            <a href="https://www.facebook.com/profile.php?id=100091992364096" target="_blank" class="social-icon" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="https://www.instagram.com/dpsssiddipet/" target="_blank" class="social-icon" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                            </a>
                            <a href="https://x.com/DPSS_SIDDIPET?s=08" target="_blank" class="social-icon" aria-label="Twitter">
                            <i class="fab fa-twitter"></i>
                            </a>
                            <a href="https://www.linkedin.com/in/dps-cherukupalli-93abb2232/" target="_blank" class="social-icon" aria-label="LinkedIn">
                            <i class="fab fa-linkedin"></i>
                            </a>
                            <a href="http://www.youtube.com/@DELHIPUBLICSECONDARYSCHOOLSIDD" target="_blank" class="social-icon" aria-label="YouTube">
                              <i class="fab fa-youtube"></i>
                            </a>
                            <a href="https://wa.me/917660999981" target="_blank" class="social-icon" aria-label="whatsapp">
                              <i class="fab fa-whatsapp"></i>
                            </a>
                        
                            <!-- <a href="https://linktr.ee/idpscherukupalli" target="_blank" class="social-icon" aria-label="Linktree">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" height="20px">
                                <path d="M13.5108 5.85343L17.5158 1.73642L19.8404 4.11701L15.6393 8.12199H21.5488V11.4268H15.6113L19.8404 15.5345L17.5158 17.8684L11.7744 12.099L6.03299 17.8684L3.70842 15.5438L7.93745 11.4361H2V8.12199H7.90944L3.70842 4.11701L6.03299 1.73642L10.038 5.85343V0H13.5108V5.85343ZM10.038 16.16H13.5108V24.0019H10.038V16.16Z" fill="#fff"></path>
                            </svg>
                            </a> -->
                        </div>

                        <!-- <div class="social-links text-center text-md-right pt-3 pt-md-0">
                            <a target="_blank" href="https://x.com/DPSS_SIDDIPET?s=08" class="twitter">
                                <i class="bx bxl-twitter"></i>
                            </a>
                            <a target="_blank" href="https://www.facebook.com/profile.php?id=100091992364096" class="facebook">
                                <i class="bx bxl-facebook"></i>
                            </a>
                            <a target="_blank" href="https://www.instagram.com/dpsssiddipet/" class="instagram">
                                <i class="bx bxl-instagram"></i>
                            </a>
                            <a target="_blank" href="https://www.linkedin.com/in/dps-cherukupalli-93abb2232/" class="linkedin">
                                <i class="bx bxl-linkedin"></i>
                            </a>
                            <a href="https://wa.me/917660999981" target="_blank" title="WhatsApp" class="whatsapp">
                                <i class="bx bxl-whatsapp"></i>
                            </a>
                            <a href="http://www.youtube.com/@DELHIPUBLICSECONDARYSCHOOLSIDD" target="_blank" title="YouTube" class="youtube">
                                <i class="bx bxl-youtube"></i>
                            </a>
                        </div> -->
                    </div>
               </div>
            </div>
        </div>
        <div class="container-fluid d-flex align-items-center justify-content-between">
            
                <div class="logo-area">
                    <a href="http://www.dpsssiddipet.com/" style="margin: 0 auto;">
                        <div class='mx-sm-auto  dpssid-logo'>
                            <img src="/images/school-logo/siddipet-lg.png"  alt="Delhi Public Secondary School, Siddipet">
                        </div>
                    </a>
                    <div class="name-area">
                        <h2>Delhi Public Secondary School</h2>
                        <span>Siddipet</span>
                    </div>
                </div>
            
            <!-- <div class='d-flex'>
                <img class="d-sm-none d-lg-block" src="assets/img/newpic/azadi-logo.png">
                <img class="d-none d-lg-block" src="assets/img/newpic/G20.png">
                <img class="d-none d-lg-block" src="assets/img/newpic/digital-ind.png">
                <img class="d-none d-lg-block" src="assets/img/newpic/swach-bharat.png">
            </div> -->
        </div>
        <div style="background-color:#0E753B;">
            <nav class="nav-menu d-none d-lg-block">
                <ul>
                   
                    <li class="active"><a href="http://www.dpsssiddipet.com/">Home</a></li>
                   
                    <li class="drop-down"><a href="javascript:void(0)">About Us</a>
                        <ul>
                            <li><a href="aboutus.php">About School</a></li>
                            <li><a href="principal.php">Principal Message</a></li>
                            <li><a href="founder.php">Founder Message</a></li>
                            <!-- <li><a href="mandatory.php">Mandatory Disclosure</a></li> -->
                        </ul>
                    </li>
                    <!-- <li><a href="#mandatory.php">Mandatory Disclosure</a></li> -->
                    <li class="drop-down"><a href="">Academics</a>
                        <ul>
                            <li><a href="preprimary.php">Pre Primary</a></li>
                            <li><a href="primarySchool.php">Primary School</a></li>
                            <li><a href="middleSchool.php">Middle School</a></li>
                            <li><a href="beyondacademics.php">Beyond Academics</a></li>
                            <li><a href="assessment.php">Assessment & promotion Rules</a></li>
                        </ul>
                    </li>
                    <li class="drop-down"><a href="">Student Life</a>
                        <ul>
                            <li><a href="education.php">Education Framework</a></li>
                            <li><a href="extracurricular.php">Extra Curricular Activities</a></li>
                            <li><a href="cocurricular.php">Co Curricular Activities</a></li>
                            <li><a href="schoolpermises.php">Facilities</a>
                                
                            </li>
                            <li><a href="safety.php">Safety and Security</a></li>
                        </ul>
                    </li>
                   
                    <li class="drop-down"><a href="">Admissions</a>
                        <ul>
                         
                            <li><a href="onlineRegis.php">Online Registration</a></li>
                            <li><a href="enrollmentGuide.php">Enrollment Guide</a></li>
                            <!-- <li><a href="feeStructure.php">Fee Structure</a></li> -->
                            <li><a href="ageCriteria.php">Age criteria</a></li>
                            <li><a href="documentRequired.php">Documents Required</a></li>
                            <!-- <li><a href="OfflineRegis.php">Offline Registration</a></li> -->
                        </ul>
                    </li>
                 
                    <!-- <li class="drop-down"><a href="">Enrollment </a>
                        <ul> 
                           
                        </ul>
                    </li> -->
                    <!--  -->
                    <li><a href="events.php">Careers</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="transport.php">Transport</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </nav><!-- .nav-menu -->
        </div>
      
        </div>
    </header>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');
/* General Styling */
body {
    font-family: "Poppins", serif;
    background-color: #F8F9FA;
    color: #333333;
    margin: 0;
    padding: 20px;
}

/* Row Layout */
.row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    margin: 30px 0;
}

/* Column Layout */
.col-md-6 {
    width: 48%;
}

/* Heading Styles */
h2 {
    /* color: #005792; */
    color: #009247;
    font-size: 25px;
    font-weight: bold;
    margin-bottom: 10px;
}

/* Paragraph Styling */
p {
    font-size: 16px;
    line-height: 1.8;
    text-align: justify;
}

/* Image Styling */
.facilities-img img {
    border-radius: 10px;
    /* box-shadow: 5px 5px 15px rgba(0, 0, 0, 0.2); */
    box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
    width: 100%;
    height: 300px;
    display: block;
}

/* Centered Text */
.center-text {
    text-align: center;
    font-size: 18px;
    font-weight: 600;
    /* color: #00A8E8; */
}

.about-section {
    padding: 50px 10%;
}
.section {
    padding: 50px 0;
}
.facility-item {
    text-align: center;
    padding: 20px;
    background: #f9f9f9;
    border-radius: 10px;
    transition: 0.3s ease-in-out;
}
.facility-item:hover {
    background: #e3e3e3;
}
.facility-item img {
    max-width: 100%;
    height: auto;
    border-radius: 10px;
}
.facility-item .caption {
    margin-top: 10px;
    font-size: 1.2rem;
    font-weight: bold;
}

.facilitiess h2{
  color: #009247;
  text-align: center;
  font-size: 28px;
  font-weight: bold;

}
.caption{
    font-size: 22px;
    color:rgb(76, 170, 122);
}

/* Responsive Design */
@media (max-width: 992px) {
    .col-md-6 {
        width: 100%;
        text-align: center;
        margin-bottom: 20px;
    }

    p {
        text-align: center;
    }
}

@media (max-width: 768px) {
    h2 {
        font-size: 24px;
    }

    p {
        font-size: 14px;
    }
}
</style>
<div>
    <main id="main">
        <!-- ======= Breadcrumbs ======= -->
        <div class="breadcrumbs" data-aos="fade-in">
            <div class="breadcrumbs-inner">
                <h2>Facilities</h2>
            </div>
        </div>
        <!-- End Breadcrumbs -->
        <!-- ======= About Section ======= -->
        <section class="facilities-img">
            <!-- <h2 style="text-align: center;color: #00a1ff;">Facilities</h2> -->
            <div class="container aos-init aos-animate" data-aos="fade-in"> 
                <!-- First Section -->
                <div class="row">
                    <div class="col-md-6">
                        <h2>SCHOOL PREMISES</h2>
                        <p>Our sprawling campus has world-class infrastructure with state-of-the-art educational facilities. 
                            Our classrooms are designed to let in sufficient natural sunlight and facilitate good ventilation. 
                            We have paid special attention to designing indoor and outdoor activity centres in such a way that 
                            allows the smooth and free movement of students between various facilities.</p>
                    </div>
                    <div class="col-md-6">
                        <img src="assets/img/newpic/librarygirl.JPG" alt="Library Girl">
                    </div>
                </div>

                <!-- Second Section -->
                <div class="row">
                    <div class="col-md-6">
                        <img src="assets/img/fa.png" alt="Campus Facilities">
                    </div>
                    <div class="col-md-6">
                        <p class="">We have a wide spectrum of spaces that ensure quality campus life for students 
                            in a multi-cultural, diverse environment. Some of our campus facilities include:</p>
                    </div>
                </div>
                
            </div>
            <br>
            <div class="all-imgs">
                <div class="container section">
                    <div class="facilitiess">
                        <h2>Facilities</h2>
                    </div>
                    <div class="row g-4">
                        <div class="col-md-4 col-sm-6">
                            <div class="facility-item">
                                <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f4933dc5089_Montessori-Laboratory--icon.png" alt="Montessori Laboratory">
                                <div class="caption">Montessori Laboratory</div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="facility-item">
                                <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f1d46dc50ad_Kindergarten-Play-Area-icon.png" alt="Kindergarten Play Area">
                                <div class="caption">Kindergarten Play Area</div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="facility-item">
                                <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f34cfdc50b9_Kiddies%E2%80%99-Pool-icon.png" alt="Splash Pool">
                                <div class="caption">Splash Pool</div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="facility-item">
                                <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fa2cbdc5094_Art-%26-Craft-Lab-icon.png" alt="Art & Craft Lab">
                                <div class="caption">Art & Craft Lab</div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="facility-item">
                                <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fbbbedc5088_library-icon.png" alt="Library">
                                <div class="caption">Library</div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6">
                            <div class="facility-item">
                                <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f68a2dc508e_it-hub-icon.png" alt="IT Lab">
                                <div class="caption">IT Lab</div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <div class="div-block-68">
                    <div class="div-block-55 full-width"><img
                            src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f4933dc5089_Montessori-Laboratory--icon.png"
                            width="250" alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Montessori Laboratory</div>
                    </div>
                    <div class="div-block-55 full-width"><img
                            src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f1d46dc50ad_Kindergarten-Play-Area-icon.png"
                            width="250"
                            sizes="(max-width: 479px) 100px, (max-width: 767px) 21vw, (max-width: 991px) 17vw, (max-width: 1279px) 10vw, (max-width: 1919px) 11vw, 150px"
                            srcset="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f1d46dc50ad_Kindergarten-Play-Area-icon-p-500.png 500w, https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f1d46dc50ad_Kindergarten-Play-Area-icon.png 660w"
                            alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Kindergarten Play Area</div>
                    </div>
                    <div class="div-block-55 full-width"><img
                            src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f34cfdc50b9_Kiddies%E2%80%99-Pool-icon.png"
                            width="250"
                            sizes="(max-width: 479px) 93vw, (max-width: 991px) 17vw, (max-width: 1279px) 10vw, (max-width: 1919px) 11vw, 150px"
                            srcset="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f34cfdc50b9_Kiddies%25E2%2580%2599-Pool-icon-p-500.png 500w, https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f34cfdc50b9_Kiddies%E2%80%99-Pool-icon.png 660w"
                            alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Splash Pool</div>
                    </div>
                    <div class="div-block-55 full-width"><img
                            src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fa2cbdc5094_Art-%26-Craft-Lab-icon.png"
                            width="250"
                            sizes="(max-width: 479px) 93vw, (max-width: 991px) 17vw, (max-width: 1279px) 10vw, (max-width: 1919px) 11vw, 150px"
                            srcset="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fa2cbdc5094_Art-%2526-Craft-Lab-icon-p-500.png 500w, https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fa2cbdc5094_Art-%26-Craft-Lab-icon.png 660w"
                            alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Art &amp; Craft Lab</div>
                    </div>
                    <div class="div-block-55 full-width"><img
                            src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fbbbedc5088_library-icon.png"
                            width="250" alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Library</div>
                    </div>
                    <div class="div-block-55 full-width"><img
                            src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f68a2dc508e_it-hub-icon.png"
                            width="250"
                            sizes="(max-width: 479px) 100px, (max-width: 767px) 21vw, (max-width: 991px) 17vw, (max-width: 1279px) 10vw, (max-width: 1919px) 11vw, 150px"
                            srcset="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f68a2dc508e_it-hub-icon-p-500.png 500w, https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f68a2dc508e_it-hub-icon.png 660w"
                            alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">IT Lab</div>
                    </div>
                    <div class="div-block-55 full-width"><img
                            src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f4008dc50cf_maths-icon.png"
                            width="250"
                            sizes="(max-width: 479px) 93vw, (max-width: 991px) 17vw, (max-width: 1279px) 10vw, (max-width: 1919px) 11vw, 150px"
                            srcset="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f4008dc50cf_maths-icon-p-500.png 500w, https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f4008dc50cf_maths-icon.png 660w"
                            alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Maths Lab</div>
                    </div>
                    <div class="div-block-55 full-width"><img
                            src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fbc5fdc508a_audio-visual-room-icon.png"
                            width="250" alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Audio-Video Visual Room</div>
                    </div>
                    <div class="div-block-55 full-width"><img
                            src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f32acdc50af_football-ground-icon.png"
                            width="250"
                            sizes="(max-width: 479px) 100px, (max-width: 767px) 21vw, (max-width: 991px) 17vw, (max-width: 1279px) 10vw, (max-width: 1919px) 11vw, 150px"
                            srcset="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f32acdc50af_football-ground-icon-p-500.png 500w, https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f32acdc50af_football-ground-icon.png 660w"
                            alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Football Ground</div>
                    </div>
                    <div class="div-block-55 full-width"><img
                            src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f2f03dc50b6_indoor-sports---icon.png"
                            width="250"
                            sizes="(max-width: 479px) 100px, (max-width: 767px) 21vw, (max-width: 991px) 17vw, (max-width: 1279px) 10vw, (max-width: 1919px) 11vw, 150px"
                            srcset="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f2f03dc50b6_indoor-sports---icon-p-500.png 500w, https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f2f03dc50b6_indoor-sports---icon.png 660w"
                            alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Indoor Sports</div>
                    </div>
                    <div id="w-node-_39df821f-b457-8e9c-f6c8-c4faf72df28f-63dc4ee2" class="div-block-55 full-width">
                        <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f2150dc509e_gandhi---icon.png"
                            width="250"
                            sizes="(max-width: 479px) 93vw, (max-width: 991px) 17vw, (max-width: 1279px) 10vw, (max-width: 1919px) 11vw, 150px"
                            srcset="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f2150dc509e_gandhi---icon-p-500.png 500w, https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f2150dc509e_gandhi---icon.png 660w"
                            alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Mahatma Gandhi Centre <br>for Universal
                            Values
                        </div>
                    </div>
                    <div id="w-node-ae142a50-0906-a418-5bb5-ea61f2a13418-63dc4ee2" class="div-block-55 full-width">
                        <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fdad1dc51b4_science-pshysics%2C-chemistry-icon.png"
                            width="250"
                            sizes="(max-width: 479px) 93vw, (max-width: 991px) 17vw, (max-width: 1279px) 10vw, (max-width: 1919px) 11vw, 150px"
                            srcset="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fdad1dc51b4_science-pshysics%252C-chemistry-icon-p-500.png 500w, https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fdad1dc51b4_science-pshysics%2C-chemistry-icon.png 600w"
                            alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Maths and Science Labs</div>
                    </div>
                    <div id="w-node-bceaee1d-05a7-1844-795d-4cddc0cebe42-63dc4ee2" class="div-block-55 full-width">
                        <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218f1141dc51b5_multi-purpose-hall.png"
                            width="250" alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Multipurpose Hall</div>
                    </div>
                    <div id="w-node-_5ef1acc4-edca-068a-2a4c-f6645711f073-63dc4ee2" class="div-block-55 full-width">
                        <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fa6b0dc51b6_infirmary-icon.png"
                            width="250" alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Infirmary</div>
                    </div>
                    <div id="w-node-_33a2a0cd-e167-a97b-abb7-44a71456c27f-63dc4ee2" class="div-block-55 full-width">
                        <img src="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fc1f5dc51b7_skating-icon.png"
                            width="250"
                            sizes="(max-width: 479px) 93vw, (max-width: 991px) 17vw, (max-width: 1279px) 10vw, (max-width: 1919px) 11vw, 150px"
                            srcset="https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fc1f5dc51b7_skating-icon-p-500.png 500w, https://assets-global.website-files.com/5f369f58e2218fa47ddc4e55/5f369f58e2218fc1f5dc51b7_skating-icon.png 600w"
                            alt="" class="value-icon">
                        <div class="caption" style="text-align: center;">Skating Rink</div>
                    </div>
                </div>                 -->
            </div>
            <br>
            <div class="container">
                <!-- Natural Sunlight Section -->
                <div class="row">
                    <div class="col-md-6">
                        <img src="assets/img/newpic/sunlight.jpg" alt="Natural Sunlight">
                    </div>
                    <div class="col-md-6">
                        <h2>NATURAL SUNLIGHT</h2>
                        <p>We know the health benefits of exposing our students to the natural rays of the sun, 
                            which is why the architectural structure of our campus is such that it is flooded 
                            with natural sunlight throughout the day. LED lights, a resource-efficient option, are used 
                            only when this natural light dims or is short in supply.</p>
                    </div>
                </div>

                <!-- Physical Health Section -->
                <div class="row">
                    <div class="col-md-6">
                        <h2>PHYSICAL HEALTH</h2>
                        <p>We have taken special care to promote physical activity among students 
                            while they are on campus, which can boost their health. Walkable environments within 
                            and outside the campus connect students to green spaces and therapeutic landscapes, 
                            encouraging physical activity and potentially reducing absenteeism due to ill health.</p>
                    </div>
                    <div class="col-md-6">
                        <img src="assets/img/newpic/physical-activity.jpg" alt="Physical Activity">
                    </div>
                </div>

                <!-- Indoor Environment Quality Section -->
                <div class="row">
                    <div class="col-md-6">
                        <img src="assets/img/newpic/indoor activity.JPG" alt="Indoor Environment Quality">
                    </div>
                    <div class="col-md-6">
                        <h2>INDOOR ENVIRONMENT QUALITY</h2>
                        <p>The environment within the premises is also an important factor in the healthy development 
                            of students. Our building is designed to ensure high indoor air quality, the correct temperature, 
                            adequate lighting, and proper ventilation. We have carefully selected building materials to 
                            complement each of these requirements for the highest benefit to our students.</p>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>


<footer id="footer" style="background: #0E753B!important;">
        <div class="footer-top" style="background-color: #0E753B;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 footer-contact">
                        <!-- <h3>Mentor</h3> -->
                        <h3><strong>SCHOOL LOCATION</strong></h3>
                        <p>
                            <!-- A108 Adam Street <br> -->
                            <strong>
                                <p>Delhi Public Secondary School</p>
                            </strong>
                            Srinivasa Nagar Road,<br>
                            Near-Police Convention Hall<br>
                            Siddipet, Telangana 502103<br><br>
                            <strong>Parents Help line Desk</strong><br>
                            Mobile No:  +91 7660999981 , 7660999931<br><br>
                            <!-- <strong>Office Contacts</strong><br>
                            Mobile No: 7799 7979 32<br>
                            Landline No: 08648293020<br> -->
                            <!-- <strong>Email:</strong> info@example.com<br> -->
                            <strong>Email:</strong> dpsssiddipet@gmail.com<br>
                        </p>
                    </div>
                    <div class="col-lg-4 col-md-6 footer-links">
                        <h4>Useful Links</h4>
                        <ul>
                            
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-6 footer-links">
                        <h4>Our Services</h4>
                        <ul>
                            
                            <li><i class="bx bx-chevron-right"></i>Teachers from all states</li>
                            <li><i class="bx bx-chevron-right"></i>Activity Based Learning</li>
                            <li><i class="bx bx-chevron-right"></i>Best Digital Library</li>
                            <li><i class="bx bx-chevron-right"></i>Outdoor Sports Facility</li>
                            <!-- <li><i class="bx bx-chevron-right"></i>Swimming Pool & GYM</li> -->
                        </ul>
                    </div>
                    
                </div>
            </div>
        </div>
        <div class="container d-md-flex py-4" >
            <div class="mr-md-auto text-center text-md-left">
                <div class="copyright">
                    <!-- &copy; Copyright <strong><span>Mentor</span></strong>. All Rights Reserved -->
                    &copy; Copyright <strong><span>Delhi Public Secondary School</span></strong>. All Rights Reserved
                </div>
                <!-- <div class="credits">
                   
                    Designed by <a target='_blank' href="https://www.amaravathisoftware.com/">Amaravathi Software
                        Innovations.</a>
                </div> -->
            </div>
            <div class="social-links text-center text-md-right pt-3 pt-md-0">
                <a target="_blank" href="https://x.com/DPSS_SIDDIPET?s=08" class="twitter">
                    <i class="bx bxl-twitter"></i>
                </a>
                <a target="_blank" href="https://www.facebook.com/profile.php?id=100091992364096" class="facebook">
                    <i class="bx bxl-facebook"></i>
                </a>
                <a target="_blank" href="https://www.instagram.com/dpsssiddipet/" class="instagram">
                    <i class="bx bxl-instagram"></i>
                </a>
                <!-- <a href="#" class="google-plus">
                    <i class="bx bxl-skype"></i>
                </a> -->
                <a target="_blank" href="https://www.linkedin.com/in/dps-cherukupalli-93abb2232/" class="linkedin">
                    <i class="bx bxl-linkedin"></i>
                </a>
                <a href="https://wa.me/917660999981" target="_blank" title="WhatsApp" class="whatsapp">
                    <i class="bx bxl-whatsapp"></i>
                </a>
                <a href="http://www.youtube.com/@DELHIPUBLICSECONDARYSCHOOLSIDD" target="_blank" title="YouTube" class="youtube">
                    <i class="bx bxl-youtube"></i>
                </a>
            </div>
        </div>
    </footer><!-- End Footer -->
    <a href="#" class="back-to-top"><i class="bx bx-up-arrow-alt"></i></a>
    <div id="preloader"></div>
    <!-- Vendor JS Files -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counterup/counterup.min.js"></script>
    <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>
    <!-- website cdns -->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.25/angular.min.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.2.25/angular-route.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/angular-ui-router/0.2.10/angular-ui-router.js"></script>
    <!-- <script src="js/routesWeb.js"></script> -->
    <script src="assets/js/routes.js"></script>
    <!-- <script src="js/controllerWeb.js"></script> -->
    <script src="assets/js/controller.js"></script>
</body>
</html>
<script>
$(document).ready(function() {
    setInterval(function() {
        var now = new Date();
        var date = now.toLocaleDateString();
        var time = now.toLocaleTimeString();
        var datetime1 = now.toLocaleString();
        var datetime2 = now.toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: true
        });
        var datetime3 = now.toLocaleString('en-GB', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: false
        });
        $("#date").text(date);
        $("#time").text(time);
        $("#datetime1").text(datetime1);
        $("#datetime2").text(datetime2);
        $("#datetime3").text(datetime3);
    }, 1000);
});
</script>
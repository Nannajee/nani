
<html lang="en" ng-app="schoolApp">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
  
    <title>Delhi Public Secondary School | Top CBSE School with Global Standards & Offering Franchise Success</title>
    <meta content="" name="description">
    <meta content="" name="keywords">
    <!-- Favicons -->
    <link href="/images/school-logo/siddipet-lg.png" rel="icon">
    <link href="/images/school-logo/siddipet-lg.png" rel="dpsslogo">
    <link href="/images/school-logo/siddipet-lg.png" rel="apple-touch-icon">
    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">
    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body ng-controller="mainCtrl">
    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top">
        
        <div class="top-head">
            <div class="row">
                <!-- <div class="col-sm-12 col-md-4 col-lg-4 ">
                  <div style="color:white;" id="datetime2"></div>
               </div> -->
               <div class="col-sm-12 col-md-4 col-lg-4 ">
                    <div class="helpline">
                        <span style="margin-left: 10px;">
                            Admissions Helpline:
                            <i class="bi bi-telephone-fill"></i> +91 7660999981 |
                            <i class="bi bi-envelope-fill"></i> dpsssiddipet@gmail.com
                        </span>
                    </div>
               </div>
               <div class="col-sm-12 col-md-8 col-lg-8 ">
                    <div class="top-navbar-items">
                        <div class="header-top_nav">
                            <!-- <div class="hdr-li"><a href="#" target="_blank"><i class="fa fa-sign-in"></i>&nbsp; ERP Login</a> </div>  -->
                            <!-- <div class="hdr-li"><a href="#"> | </a> </div>  -->
                            <div class="hdr-li"><a href="javascript:void(0)"><i class="fa fa-file-text"></i>&nbsp; Mandatory Disclosure</a> </div> 
                            <div class="hdr-li"><a href="#"> | </a> </div> 
                            <div class="hdr-li"><a href="onlineRegis.php"><i class="far fa-edit"></i>&nbsp; Admission Enquiry Form</a> </div>
                            <div class="hdr-li"><a href="#"> | </a> </div>
                            <div class="hdr-li"><a href="javascript:void(0)"><i class="fas fa-paper-plane"></i>&nbsp; Notice </a></div>
                            <div class="hdr-li"><a href="#"> | </a> </div>
                            <div class="hdr-li"><a href="javascript:void(0)"><img src="/images/school-logo/360-icon.webp" style="margin-top: -4px; max-width: 26px; margin-right: 3px;">View</a>
                            </div>
                        </div>
                        
                        <div class="social-icons">
                            <a href="https://www.facebook.com/profile.php?id=100091992364096" target="_blank" class="social-icon" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="https://www.instagram.com/dpsssiddipet/" target="_blank" class="social-icon" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                            </a>
                            <a href="https://x.com/DPSS_SIDDIPET?s=08" target="_blank" class="social-icon" aria-label="Twitter">
                            <i class="fab fa-twitter"></i>
                            </a>
                            <a href="https://www.linkedin.com/in/dps-cherukupalli-93abb2232/" target="_blank" class="social-icon" aria-label="LinkedIn">
                            <i class="fab fa-linkedin"></i>
                            </a>
                            <a href="http://www.youtube.com/@DELHIPUBLICSECONDARYSCHOOLSIDD" target="_blank" class="social-icon" aria-label="YouTube">
                              <i class="fab fa-youtube"></i>
                            </a>
                            <a href="https://wa.me/917660999981" target="_blank" class="social-icon" aria-label="whatsapp">
                              <i class="fab fa-whatsapp"></i>
                            </a>
                        
                            <!-- <a href="https://linktr.ee/idpscherukupalli" target="_blank" class="social-icon" aria-label="Linktree">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" height="20px">
                                <path d="M13.5108 5.85343L17.5158 1.73642L19.8404 4.11701L15.6393 8.12199H21.5488V11.4268H15.6113L19.8404 15.5345L17.5158 17.8684L11.7744 12.099L6.03299 17.8684L3.70842 15.5438L7.93745 11.4361H2V8.12199H7.90944L3.70842 4.11701L6.03299 1.73642L10.038 5.85343V0H13.5108V5.85343ZM10.038 16.16H13.5108V24.0019H10.038V16.16Z" fill="#fff"></path>
                            </svg>
                            </a> -->
                        </div>

                        <!-- <div class="social-links text-center text-md-right pt-3 pt-md-0">
                            <a target="_blank" href="https://x.com/DPSS_SIDDIPET?s=08" class="twitter">
                                <i class="bx bxl-twitter"></i>
                            </a>
                            <a target="_blank" href="https://www.facebook.com/profile.php?id=100091992364096" class="facebook">
                                <i class="bx bxl-facebook"></i>
                            </a>
                            <a target="_blank" href="https://www.instagram.com/dpsssiddipet/" class="instagram">
                                <i class="bx bxl-instagram"></i>
                            </a>
                            <a target="_blank" href="https://www.linkedin.com/in/dps-cherukupalli-93abb2232/" class="linkedin">
                                <i class="bx bxl-linkedin"></i>
                            </a>
                            <a href="https://wa.me/917660999981" target="_blank" title="WhatsApp" class="whatsapp">
                                <i class="bx bxl-whatsapp"></i>
                            </a>
                            <a href="http://www.youtube.com/@DELHIPUBLICSECONDARYSCHOOLSIDD" target="_blank" title="YouTube" class="youtube">
                                <i class="bx bxl-youtube"></i>
                            </a>
                        </div> -->
                    </div>
               </div>
            </div>
        </div>
        <div class="container-fluid d-flex align-items-center justify-content-between">
            
                <div class="logo-area">
                    <a href="http://www.dpsssiddipet.com/" style="margin: 0 auto;">
                        <div class='mx-sm-auto  dpssid-logo'>
                            <img src="/images/school-logo/siddipet-lg.png"  alt="Delhi Public Secondary School, Siddipet">
                        </div>
                    </a>
                    <div class="name-area">
                        <h2>Delhi Public Secondary School</h2>
                        <span>Siddipet</span>
                    </div>
                </div>
            
            <!-- <div class='d-flex'>
                <img class="d-sm-none d-lg-block" src="assets/img/newpic/azadi-logo.png">
                <img class="d-none d-lg-block" src="assets/img/newpic/G20.png">
                <img class="d-none d-lg-block" src="assets/img/newpic/digital-ind.png">
                <img class="d-none d-lg-block" src="assets/img/newpic/swach-bharat.png">
            </div> -->
        </div>
        <div style="background-color:#0E753B;">
            <nav class="nav-menu d-none d-lg-block">
                <ul>
                   
                    <li class="active"><a href="http://www.dpsssiddipet.com/">Home</a></li>
                   
                    <li class="drop-down"><a href="javascript:void(0)">About Us</a>
                        <ul>
                            <li><a href="aboutus.php">About School</a></li>
                            <li><a href="principal.php">Principal Message</a></li>
                            <li><a href="founder.php">Founder Message</a></li>
                            <!-- <li><a href="mandatory.php">Mandatory Disclosure</a></li> -->
                        </ul>
                    </li>
                    <!-- <li><a href="#mandatory.php">Mandatory Disclosure</a></li> -->
                    <li class="drop-down"><a href="">Academics</a>
                        <ul>
                            <li><a href="preprimary.php">Pre Primary</a></li>
                            <li><a href="primarySchool.php">Primary School</a></li>
                            <li><a href="middleSchool.php">Middle School</a></li>
                            <li><a href="beyondacademics.php">Beyond Academics</a></li>
                            <li><a href="assessment.php">Assessment & promotion Rules</a></li>
                        </ul>
                    </li>
                    <li class="drop-down"><a href="">Student Life</a>
                        <ul>
                            <li><a href="education.php">Education Framework</a></li>
                            <li><a href="extracurricular.php">Extra Curricular Activities</a></li>
                            <li><a href="cocurricular.php">Co Curricular Activities</a></li>
                            <li><a href="schoolpermises.php">Facilities</a>
                                
                            </li>
                            <li><a href="safety.php">Safety and Security</a></li>
                        </ul>
                    </li>
                   
                    <li class="drop-down"><a href="">Admissions</a>
                        <ul>
                         
                            <li><a href="onlineRegis.php">Online Registration</a></li>
                            <li><a href="enrollmentGuide.php">Enrollment Guide</a></li>
                            <!-- <li><a href="feeStructure.php">Fee Structure</a></li> -->
                            <li><a href="ageCriteria.php">Age criteria</a></li>
                            <li><a href="documentRequired.php">Documents Required</a></li>
                            <!-- <li><a href="OfflineRegis.php">Offline Registration</a></li> -->
                        </ul>
                    </li>
                 
                    <!-- <li class="drop-down"><a href="">Enrollment </a>
                        <ul> 
                           
                        </ul>
                    </li> -->
                    <!--  -->
                    <li><a href="events.php">Careers</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="transport.php">Transport</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </nav><!-- .nav-menu -->
        </div>
      
        </div>
    </header>
<!-- ======= Breadcrumbs ======= -->
<!-- <div class="breadcrumbs">
    <div class="container">
        <h2>AGE  CRITERIA</h2>
    </div>
</div> -->
<!-- End Breadcrumbs -->
 <br><br><br><br>
<section class="age-criter">
    <div class="container">
        <br>
        <div class="age-criter-inner">
        <div class="section-title">
            <h2>Age Criteria</h2>
            <h4 class="subtitle">Age Criteria For The Year 2024-25</h4>
        </div>
        <table id="customers">
            <tr>
                <th>Nursery & Preparatory</th>
                <th></th>
            </tr>
            <!--  -->
            <tr>
                <td>Nursery</td>
                <td>If the child is <strong>03+</strong></td>
            </tr>
            <tr>
                <td>Preparatory</td>
                <td>If the child is <strong>04+</strong></td>
            </tr>
        </table>
        <br>
        <br>
        <!-- primary(Class I - Class V) -->
        <table id="customers">
            <tr>
                <th>primary(Class I - Class V)</th>
                <th></th>
            </tr>
            <tr>
                <td>Class I</td>
                <td>If the child is <strong>06+</strong></td>
            </tr>
            <tr>
                <td>Class II</td>
                <td>If the child is <strong>07+</strong></td>
            </tr>
            <tr>
                <td>Class III</td>
                <td>If the child is <strong>08+</strong></td>
            </tr>
            <tr>
                <td>Class IV</td>
                <td>If the child is <strong>09+</strong></td>
            </tr>
            <tr>
                <td>Class V</td>
                <td>If the child is <strong>10+</strong></td>
            </tr>
        </table>
        <br>
        <br>
        <!-- primary(Class I - Class V) -->
        <!-- secondary  -->
        <table id="customers">
            <tr>
                <th>secondary(Class VI - Class X)</th>
                <th></th>
            </tr>
            <tr>
                <td>Class VI</td>
                <td>If the child is <strong>11+</strong></td>
            </tr>
            <tr>
                <td>Class VII</td>
                <td>If the child is <strong>12+</strong></td>
            </tr>
            <tr>
                <td>Class VIII</td>
                <td>If the child is <strong>13+</strong></td>
            </tr>
            <tr>
                <td>Class IX</td>
                <td>If the child is <strong>14+</strong></td>
            </tr>
            <!--  <tr>
                <td>Class X</td>
                <td>If the child is <strong>15+</strong></td>
            </tr> -->
        </table>

        <!-- secondary  -->
        </div>
    </div>
</section>
<style>
    /* General styles */
/* body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 20px;
    padding: 20px;
} */

/* .container {
    max-width: 800px;
    margin: auto;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
} */
.age-criter-inner{
    max-width: 100%;
    margin: auto;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
}
.age-criter{
    margin: 60px 0 0 0;
}

h2, h4 {
    color: #2c3e50;
  }

  h2 {
    font-size: 36px;
    font-weight: bold;
    margin-bottom: 15px;
  }

  .subtitle {
    font-size: 20px;
    color: #7f8c8d;
  }
  .section-title {
    padding-bottom: 15px;
}

/* Table styling */
#customers {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    background: #ffffff;
}

#customers th, #customers td {
    border: 1px solid #ddd;
    padding: 6px 12px;
    text-align: left;
}

#customers th {
    background-color: #0E753B;
    color: white;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
}

#customers tr:nth-child(even) {
    background-color: #f2f2f2;
}

#customers tr:hover {
    background-color: #ddd;
    transition: 0.3s;
}

/* Responsive Design */
@media screen and (max-width: 600px) {
    #customers th, #customers td {
        display: block;
        width: 100%;
    }
}

</style>


<footer id="footer" style="background: #0E753B!important;">
        <div class="footer-top" style="background-color: #0E753B;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 footer-contact">
                        <!-- <h3>Mentor</h3> -->
                        <h3><strong>SCHOOL LOCATION</strong></h3>
                        <p>
                            <!-- A108 Adam Street <br> -->
                            <strong>
                                <p>Delhi Public Secondary School</p>
                            </strong>
                            Srinivasa Nagar Road,<br>
                            Near-Police Convention Hall<br>
                            Siddipet, Telangana 502103<br><br>
                            <strong>Parents Help line Desk</strong><br>
                            Mobile No:  +91 7660999981 , 7660999931<br><br>
                            <!-- <strong>Office Contacts</strong><br>
                            Mobile No: 7799 7979 32<br>
                            Landline No: 08648293020<br> -->
                            <!-- <strong>Email:</strong> info@example.com<br> -->
                            <strong>Email:</strong> dpsssiddipet@gmail.com<br>
                        </p>
                    </div>
                    <div class="col-lg-4 col-md-6 footer-links">
                        <h4>Useful Links</h4>
                        <ul>
                            
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-4 col-md-6 footer-links">
                        <h4>Our Services</h4>
                        <ul>
                            
                            <li><i class="bx bx-chevron-right"></i>Teachers from all states</li>
                            <li><i class="bx bx-chevron-right"></i>Activity Based Learning</li>
                            <li><i class="bx bx-chevron-right"></i>Best Digital Library</li>
                            <li><i class="bx bx-chevron-right"></i>Outdoor Sports Facility</li>
                            <!-- <li><i class="bx bx-chevron-right"></i>Swimming Pool & GYM</li> -->
                        </ul>
                    </div>
                    
                </div>
            </div>
        </div>
        <div class="container d-md-flex py-4" >
            <div class="mr-md-auto text-center text-md-left">
                <div class="copyright">
                    <!-- &copy; Copyright <strong><span>Mentor</span></strong>. All Rights Reserved -->
                    &copy; Copyright <strong><span>Delhi Public Secondary School</span></strong>. All Rights Reserved
                </div>
                <!-- <div class="credits">
                   
                    Designed by <a target='_blank' href="https://www.amaravathisoftware.com/">Amaravathi Software
                        Innovations.</a>
                </div> -->
            </div>
            <div class="social-links text-center text-md-right pt-3 pt-md-0">
                <a target="_blank" href="https://x.com/DPSS_SIDDIPET?s=08" class="twitter">
                    <i class="bx bxl-twitter"></i>
                </a>
                <a target="_blank" href="https://www.facebook.com/profile.php?id=100091992364096" class="facebook">
                    <i class="bx bxl-facebook"></i>
                </a>
                <a target="_blank" href="https://www.instagram.com/dpsssiddipet/" class="instagram">
                    <i class="bx bxl-instagram"></i>
                </a>
                <!-- <a href="#" class="google-plus">
                    <i class="bx bxl-skype"></i>
                </a> -->
                <a target="_blank" href="https://www.linkedin.com/in/dps-cherukupalli-93abb2232/" class="linkedin">
                    <i class="bx bxl-linkedin"></i>
                </a>
                <a href="https://wa.me/917660999981" target="_blank" title="WhatsApp" class="whatsapp">
                    <i class="bx bxl-whatsapp"></i>
                </a>
                <a href="http://www.youtube.com/@DELHIPUBLICSECONDARYSCHOOLSIDD" target="_blank" title="YouTube" class="youtube">
                    <i class="bx bxl-youtube"></i>
                </a>
            </div>
        </div>
    </footer><!-- End Footer -->
    <a href="#" class="back-to-top"><i class="bx bx-up-arrow-alt"></i></a>
    <div id="preloader"></div>
    <!-- Vendor JS Files -->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counterup/counterup.min.js"></script>
    <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>
    <!-- website cdns -->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.25/angular.min.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.2.25/angular-route.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/angular-ui-router/0.2.10/angular-ui-router.js"></script>
    <!-- <script src="js/routesWeb.js"></script> -->
    <script src="assets/js/routes.js"></script>
    <!-- <script src="js/controllerWeb.js"></script> -->
    <script src="assets/js/controller.js"></script>
</body>
</html>
<script>
$(document).ready(function() {
    setInterval(function() {
        var now = new Date();
        var date = now.toLocaleDateString();
        var time = now.toLocaleTimeString();
        var datetime1 = now.toLocaleString();
        var datetime2 = now.toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: true
        });
        var datetime3 = now.toLocaleString('en-GB', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            hour12: false
        });
        $("#date").text(date);
        $("#time").text(time);
        $("#datetime1").text(datetime1);
        $("#datetime2").text(datetime2);
        $("#datetime3").text(datetime3);
    }, 1000);
});
</script>